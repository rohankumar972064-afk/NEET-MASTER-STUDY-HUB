// Supabase configuration — add your public project URL and anon key later.
// const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
// const SUPABASE_ANON_KEY = 'YOUR_PUBLIC_ANON_KEY';
